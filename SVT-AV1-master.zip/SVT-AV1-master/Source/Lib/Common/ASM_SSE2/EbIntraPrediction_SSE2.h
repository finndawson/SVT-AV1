/*
* Copyright(c) 2019 Intel Corporation
* SPDX - License - Identifier: BSD - 2 - Clause - Patent
*/

#ifndef EbIntraPrediction_SSE2_h
#define EbIntraPrediction_SSE2_h

#include "EbDefinitions.h"

/*******************************************
* Function pointer Table
*******************************************/
#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif // EbIntraPrediction_SSE2_h
